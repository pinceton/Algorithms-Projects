/*
 * Griffin Evans
 * April 24th, 2018
 * 
 * Implements the Furthest In Future Cache algorithm.
 * This algorithm's efficiency doesn't really matter
 * as long as it is tractable.
 * 
 * This is an oracle algorithm, giving a collision lower bounds.
 */

public class FIF extends CacheScheme{
	public int numCollisions(int cacheSize, String word){
		char[] cache = new char[cacheSize];
		boolean cacheIsNotFull = true;
		boolean newVal = true; //means that the next request is a miss.
		int nextSpot = 0; //next spot to insert the request
		int collisions = 0;
		
		for(int i = 0; i < word.length(); i++) {
			char request = word.charAt(i);
			
			//checks the cache if the request is a hit or miss
			for(int j = 0; j < cache.length; j++) {
				if (cache[j] == request) {
					newVal = false;
					break;
				} else {
					newVal = true;
				}
			}
			//if the request is not already in the cache
			if (newVal) {
				//no collision => add the request to the next spot in the cache
				if (i<cache.length) {
					cache[nextSpot] = request;
					nextSpot++;
				} 
				else { //collision
					//find the furthest char in the future
					int charToRemove = 0;
					int furthestDist = 0;
					String remainingRequests = word.substring(i+1); //gives us the remaining requests in the word
					for(int k = 0; k < cache.length; k++) {
						if (remainingRequests.indexOf(cache[k]) < 0) { //that request is not made again 
							charToRemove = k;
							break;
						} else if (remainingRequests.indexOf(cache[k]) > furthestDist) {
							//the index is further away than our current furthest distance
							furthestDist = remainingRequests.indexOf(cache[k]);
							charToRemove = k;
						}
					}
					cache[charToRemove] = request;
					collisions++;
				}
			}
			
		}
		return collisions;
	}
	
}


/*
 * Griffin Evans
 * April 26, 2018
 * 
 * First in first out.  This scheme replaces the data
 * that has been in the cache the longest.
 */

import java.util.HashMap;
import java.util.LinkedList;

public class FIFO extends CacheScheme {
	
	private Data firstChar = null;
	private Data lastChar = null;
	private HashMap<Character, Data> map = new HashMap<Character, Data>();
	
	public int numCollisions(int cacheSize, String word) {
		int currSize = 0;
		int collisions = 0;
		int hitCounter = 0;
		
		for(int i = 0; i < word.length(); i++) {
			char request = word.charAt(i);
			
			if (i == 0) {
				firstChar = new Data();
				lastChar = firstChar;
				
				firstChar.letter = request;
				map.put(request, firstChar);
				map.get(request).frequency++;
				map.get(request).cached = true;
				currSize++;
			}
			//if the map contains the key
			else if (map.containsKey(request)) {
				map.get(request).frequency = map.get(request).frequency + 1;
								
				//collision: the map contains the key, but not in the cache
				if(!(map.get(request).cached)) {
					removeFirst();
					
					//adds the request to the back of the cache
					lastChar.after = map.get(request);
					map.get(request).before = lastChar;
					map.get(request).after = null;
					map.get(request).cached = true;
					lastChar = map.get(request);
					collisions++;
				} else { //hit: the key is in the cache
					hitCounter++;
				}
			} else { //the map does not contain the key, it is new
				if (currSize < cacheSize) { //if the cache isn't full yet, add the request
					Data newRequest = new Data();
					addLast(newRequest);
					addNewRequest(newRequest, request);
					currSize++;
				} else { //collision: remove the first requested data
					Data newRequest = new Data();
					removeFirst();
					addLast(newRequest);
					addNewRequest(newRequest, request);
					collisions++;
				}
			}
		}
		return collisions;
	}

	/**
	 * helper method to update the last object in the list
	 */
	private void addLast(Data newRequest) {
		newRequest.before = lastChar;
		lastChar.after = newRequest;
		lastChar = newRequest;
		return;
	}

	/**
	 * helper method to remove the first object in the list
	 */
	private void removeFirst() {
		firstChar.cached = false;
		firstChar = firstChar.after;
		firstChar.before = null;
		return;
	}
	
	/**
	 * helper method to set up a new Data object and add it to the HashMap
	 */
	private void addNewRequest(Data newRequest, char request) {
		newRequest.frequency++;
		newRequest.cached = true;
		map.put(request, newRequest);
		return;
	}
}

import java.util.HashMap;
import java.util.PriorityQueue;

/*
 * Griffin Evans
 * April 26, 2018
 * 
 * Least frequently used Cache algorithm.
 * This algorithm replaces the piece of data that has the least 
 * number of requests.
 */


public class LFU extends CacheScheme {
	
	private HashMap<Character, Data> map = new HashMap<Character, Data>();

	public int numCollisions(int cacheSize, String word){
		PriorityQueue<Data> myQ = new PriorityQueue<Data>(cacheSize);
		int currSize = 0;
		int collisions = 0;
		int hitCounter = 0;
		
		for(int i = 0; i < word.length(); i++) {
			char request = word.charAt(i);
			
			if (i == 0) {
				Data newRequest = new Data();
				//helper method to add the new request to the HashMap
				setUpNewVal(newRequest, request);
				map.get(request).cached = true;
				myQ.add(map.get(request));
				currSize++;
			}
			//if the map contains the key
			else if (map.containsKey(request)) {
				map.get(request).frequency = map.get(request).frequency + 1;
				
				//collision: the map contains the key, but not in the cache
				if(!(map.get(request).cached)) {
					map.get(request).cached = true;
					
					Data removedVal = myQ.poll(); //place holder used to set cached to false
					map.get(removedVal.letter).cached = false; //removes the lowest priority from queue
					myQ.add(map.get(request));
					collisions++;
				} else { //hit: the key is in the cache
					hitCounter++;
					myQ.remove(map.get(request));
					myQ.add(map.get(request)); //add the request back on with the updated value
				}
			} else { //the map does not contain the key, it is new
				if (currSize < cacheSize) { //if the cache isn't full yet, add the request
					Data newRequest = new Data();
					setUpNewVal(newRequest, request);
					map.get(request).cached = true;
					myQ.add(newRequest);
					currSize++;
				} else { //collision: remove the first requested data
					Data newRequest = new Data();
					setUpNewVal(newRequest, request);
					map.get(request).cached = true;
					
					//removes the lowest priority request
					Data removedVal = myQ.poll(); //place holder used to set cached to false
					map.get(removedVal.letter).cached = false; 
					myQ.add(map.get(request)); //adds the new request to the pq
					collisions++;
				}
			}
		}
		return collisions;
	}

	/**
	 * Helper method for creating a new Data object and adding it to the HashMap
	 * @param newRequest - the new Data object
	 * @param request - the character key
	 */
	private void setUpNewVal(Data newRequest, char request) {
		newRequest.letter = request;
		newRequest.frequency++;
		map.put(request, newRequest);
		return;
	}
}

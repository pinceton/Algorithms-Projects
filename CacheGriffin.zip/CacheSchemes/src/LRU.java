import java.util.HashMap;
import java.util.LinkedList;

/*
 * Griffin Evans
 * April 26, 2018
 * 
 * Least recently used cache algorithm
 * 
 * This algorithm replaces the data in the cache 
 * with the oldest last request.
 */


public class LRU extends CacheScheme {
	
	public int numCollisions(int cacheSize, String word){
		HashMap<Character, Data> map = new HashMap<Character, Data>();
		Data firstChar = null;
		Data lastChar = null;
		int currSize = 0;
		int collisions = 0;
		int hitCounter = 0;
		
		for(int i = 0; i < word.length(); i++) {
			char request = word.charAt(i);
			
			if (i == 0) {
				firstChar = new Data();
				lastChar = firstChar;
				
				firstChar.letter = request;
				map.put(request, firstChar);
				map.get(request).frequency++;
				map.get(request).cached = true;
				currSize++;
			}
			//if the map contains the key
			else if (map.containsKey(request)) {
				map.get(request).frequency = map.get(request).frequency + 1;
								
				//collision: the map contains the key, but not in the cache
				if(map.get(request).before == null && map.get(request).after == null) {
					//removes the head and sets it's before/after to null
					Data tempSecondChar = firstChar.after; //placeholder for the second spot
					tempSecondChar.before = null; //makes the second value in cache into the first
					firstChar.after = null;
					firstChar = tempSecondChar;
					
					//adds the request to the back of the cache
					lastChar.after = map.get(request);
					map.get(request).before = lastChar;
					lastChar = map.get(request);
					collisions++;
				} else { //hit: the key is in the cache, rearrange
					hitCounter++;
					//update the list: move the requested char to the back
					if(map.get(request).before == null) { //front of cache
						map.get(request).after.before = null;
						firstChar = map.get(request).after; //get rid of the head
						lastChar.after = map.get(request);
						map.get(request).before = lastChar;
						lastChar = map.get(request);
					} else if (map.get(request).after == null) { //back of cache
						//doesn't move
					} else { //middle
						map.get(request).before.after = map.get(request).after;
						map.get(request).after.before = map.get(request).before;
						lastChar.after = map.get(request);
						map.get(request).before = lastChar;
						lastChar = map.get(request);
					}
				}
			} else { //the map does not contain the key, it is new
				if (currSize < cacheSize) { //if the cache isn't full yet, add the request
					Data newRequest = new Data();
					newRequest.before = lastChar;
					lastChar.after = newRequest;
					lastChar = newRequest;
					
					newRequest.frequency++;
					map.put(request, newRequest);
					currSize++;
				} else { //collision: remove the least recently used data
					Data newRequest = new Data();

					Data tempSecondChar = firstChar.after; //placeholder for the second spot
					tempSecondChar.before = null; //makes the second value in cache into the first
					firstChar.after = null;
					firstChar = tempSecondChar;
					
					newRequest.before = lastChar;
					lastChar.after = newRequest;
					
					lastChar = newRequest;
					newRequest.frequency++;
					map.put(request, newRequest);
					collisions++;
				}
			}
		}
		return collisions;
	}
}


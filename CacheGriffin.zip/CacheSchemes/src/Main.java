/**
 * Creates a cache of requests using FIFO, FIF, LFU, and LRU
 * and returns the number of total collisions received for each
 * algorithm.
 * 
 * @author Griffin Evans
 * April 26, 2018
 *
 */

public class Main {

	public static void main(String[] args) {
		SchemeComparisons compare = new SchemeComparisons();
		compare.userCompare();
//		LFU lfu = new LFU();
//		FIF fif = new FIF();
//		FIFO fifo = new FIFO();
//		LRU lru = new LRU();
//		System.out.print("Using LFU for string ABACDEBDA gives a total collisions of:");
//		System.out.println(lfu.numCollisions(3,"ABACDEBDA"));
//		System.out.println();
//		System.out.print("Using FIF for string ABACDEBDA gives a total collisions of:");
//		System.out.println(fif.numCollisions(3,"ABACDEBDA"));
//		System.out.println();
//		System.out.print("Using FIFO for string ABACDEBDA gives a total collisions of:");
//		System.out.println(fifo.numCollisions(3,"ABACDEBDA"));
//		System.out.println();
//		System.out.print("Using LRU for string ABACDEBDA gives a total collisions of:");
//		System.out.println(lru.numCollisions(3,"ABACDEBDA"));
//		System.out.println();
	}
}

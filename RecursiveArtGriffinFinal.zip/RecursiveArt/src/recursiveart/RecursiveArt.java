package recursiveart;

import java.awt.*;
import java.util.Random;

import processing.core.PApplet;
/**
 * RecursiveArt.java 1.0 Feb 21, 2018
 * 
 * This program draws some pretty pictures
 * using recursion
 * 
 * Copyright (c) 2018 Griffin Evans. All Rights Reserved
 * Campus Box 12810, Elon University, Elon, NC 27244
 * 
 * **SEIZURE WARNING**
 */

public class RecursiveArt extends PApplet {
	
	/*
	 * The setup sets the initial size, 
	 * adds smoothing (for pixelated lines)
	 * and noStroke, which takes out outlines of shapes.
	 * This method is called once - when the program starts.
	 */
	public void setup() {
		size(800,800);
		smooth();
		noStroke();
	}

	/*
	 * The draw program is called many times a second.
	 * It draws shapes to the screen.
	 * 
	 * The art should still be correct when the window is resized.
	 */
	public void draw() {
		// Draw background first.
		background(255,255,255);
		// Draw the target
		drawTarget(255, 0, width/2, width/4, width/4);		
		// Draw the "dream catcher"
		drawDreamCatcher(width/2, width/2, 0, 175, 150);
		// Draw the triangles
		drawTriangles(0,width/2, 0,width, width/2,width);
		
		// Draw whatever you want as long as its recursive.
		drawFeverDream(width/2, width/2, width/2);
	}
	
  /**
   * Creates 4 circle arcs in each corner and recursively makes smaller arcs within
   * the larger arc.
   *
   * @param int arcWidth - the size of the arcs
   * @param int xPos - the x position for the first arc
   * @param int yPos - the y position for the first arc
   */
	private void drawFeverDream(int arcWidth, int xPos, int yPos) {
		if (arcWidth <= 25) {
			return;
		} else {
			Random randColor = new Random();
			int colorRed = randColor.nextInt(200) + 1;
			int colorGreen = randColor.nextInt(200) + 1;
			int colorBlue = randColor.nextInt(200) + 1;
			
			fill(colorRed,colorGreen,colorBlue);
			//top left
			arc(xPos, yPos, arcWidth, arcWidth, 0, PI/2);
			//top right
			arc(xPos+xPos, yPos, arcWidth, arcWidth, PI/2, PI);
			//bottom left
			arc(xPos, yPos+yPos, arcWidth, arcWidth, 3*PI/2, TWO_PI);
			//bottom right
			arc(xPos+xPos, yPos+yPos, arcWidth, arcWidth, PI, 3*PI/2);
			
			drawFeverDream(arcWidth/2, xPos, yPos);
		}
	}

  /**
   * Creates a dream catcher design recursively using rectangles and diamonds
   * that become smaller with each recursion.
   *
   * @param int recWidth - the size of the rectangle
   * @param int xPos - the x position for the first arc
   * @param int yPos - the y position for the first arc
   * @param int redColor - the amount of red in the shape's fill color
   * @param int greenColor - the amount of green in the shape's fill color
   */
	private void drawDreamCatcher(int recWidth, int xPos, int yPos, int redColor, int greenColor) {
		if (recWidth <= 2) {
			return;
		} else {
			fill(redColor,greenColor,255); //purple square
			rect(xPos, yPos, recWidth, recWidth);
			fill(255,255,255); //white diamond
			quad((recWidth/2 + xPos),yPos, xPos,(recWidth/2 + yPos),  (xPos + recWidth/2),(yPos + recWidth), (xPos + recWidth),(yPos + recWidth/2));
			
			drawDreamCatcher(recWidth/2, (xPos + recWidth/4), (yPos + recWidth/4), redColor, greenColor);
		}
	}

  /**
   * Creates a target design recursively using different colored circles
   * that become smaller with each recursion. Keeps track of the fill color since
   * it alternates after each iteration.
   *
   * @param int size - the size of the circle
   * @param int xPos - the x position for the circle
   * @param int yPos - the y position for the circle
   * @param int colorRed - the amount of red in the shape's fill color
   * @param int colorBlue - the amount of blue in the shape's fill color
   */
	public void drawTarget(int colorRed, int colorBlue, int size, int xPos, int yPos) {
		fill(colorRed,0,colorBlue);
		if (size < 30) {
			return;
		} else {
			ellipse(xPos, yPos, size, size);
			if (colorRed == 255) { //if the previous circle was red, change it to blue
				colorRed = 0;
				colorBlue = 255;
			} else {
				colorRed = 255;
				colorBlue = 0;
			}
			drawTarget(colorRed, colorBlue, size-40, xPos, yPos);
		}
	}
	
  /**
   * Creates a red and blue triangle, and then recursively creates 3 smaller triangles
   * to the left, top, and right of that triangle using 3 separate recursions.
   *
   * @param int x1 - the x coordinate for the first corner
   * @param int y1 - the y coordinate for the first corner
   * @param int x2 - the x coordinate for the second corner
   * @param int y2 - the y coordinate for the second corner
   * @param int x3 - the x coordinate for the third corner
   * @param int y3 - the y coordinate for the third corner
   */
	private void drawTriangles(int x1, int y1, int x2, int y2, int x3, int y3) {
		if ((y2-y1) < 5) {
			return;
		} else {
			fill(255,255,0); //yellow triangle
			triangle(x1,y1,x2,y2,x3,y3);
			fill(0,0,255); //blue triangle
			triangle(x1,y1,x3,y1,x3,y3);
			
			//left triangles
			drawTriangles(x1, y1, x1, y1+(y2-y1)/2, x1+(x3-x2)/2, y1+(y2-y1)/2);
			//top triangles
			drawTriangles(x1+(x3-x2)/2, y1, x1+(x3-x2)/2, y1+(y2-y1)/2, x3, (y2+y1)/2);
			//right triangles
			drawTriangles(x1+(x3-x2)/2, y1+(y2-y1)/2, x1+(x3-x2)/2, y2, x3, y3);
		}
	}

}